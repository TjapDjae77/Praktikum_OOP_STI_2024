import java.util.*;

class MyQueue {
    // Definisi variabel penggunaan stack
    private Stack<Integer> s1;
    private Stack<Integer> s2;

    // Konstruktor
    public MyQueue() {
        s1 = new Stack<Integer>();
        s2 = new Stack<Integer>();
    }

    // Menambah elemen x ke belakang Queue
    public void push(int x) {
        s1.push(x);
        s2.push(x);
        Stack<Integer> tempstack = new Stack<Integer>();
        
        for(int i = 0; i < s1.size(); i++){
            int get = s2.pop();
            tempstack.push(get);
        }
        // for(int i = 0; i < s1.size(); i++){
        //     int get = tempstack.pop();
        //     s2.push(get);
        // }
        s2 = tempstack;
    }

    // Menghapus elemen dari depan Queue dan mengembalikan elemen tersebut
    public int pop() {
        Stack<Integer> tempstack = new Stack<Integer>();
        for(int i = 0; i < s2.size(); i++){
            int get = s1.pop();
            tempstack.push(get);
        }
            
        int sampah = tempstack.pop();
            
        for(int i = 0; i < s2.size(); i++){
            int get = tempstack.pop();
            s1.push(get);
        }
        
        int top = s2.pop();

        return top;
    }

    // Mengembalikan elemen depan Queue
    public int peek() {
        return s2.peek();
    }

    // Mengembalikan apakah Queue kosong (true) atau tidak (false)
    public boolean empty() {
        return s2.empty();
    }

    public Stack<Integer> getStack1(){
        return s1;
    }
    public Stack<Integer> getStack2(){
        return s2;
    }
}