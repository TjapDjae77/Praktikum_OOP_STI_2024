// NIM : 18222105
// NAMA: RAJENDRA FARRAS RAYHAN
import java.util.Stack;

public class Box <U>{
    private Stack<U> items;

    public Box() {
        // Menginisialisasi items
        items = new Stack<U>();
    }
    
    public void addItem(U item) {
        // Menambahkan item ke dalam items
        this.items.push(item);
    }

    public void removeItem() {
        // Menghapus item dari items
        if(!isEmpty()){
            items.pop();
        }
    }

    public Stack<U> getItems() {
        // Mengembalikan list of items
        return this.items;
    }

    public boolean isEmpty() {
        // Mengembalikan true jika items kosong
        return items.empty();
    }
}