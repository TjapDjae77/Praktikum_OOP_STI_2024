public class Shirt {
    public String shirtColor;

    public Shirt(String color) {
        this.shirtColor = color;
    }
}