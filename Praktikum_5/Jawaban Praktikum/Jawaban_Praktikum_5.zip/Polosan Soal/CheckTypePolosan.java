public class CheckType<T>{
    private T t;
    private String type;

    public CheckType(T t){
        //Konstruktor
    }
    public T getT(){
        //Kembalikan nilai t
    }
    public String getType(){
        //Kembalikan tipe data T
    }
    public String printTypeandValue(){
        //Kembalikan nilai "Tipe: Nilai"
        //Contoh "String: Halo"
    }
}