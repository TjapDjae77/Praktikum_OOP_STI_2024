import java.lang.System;
import java.util.Scanner;
 

public class BoxDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String warnabaju = sc.next();
        Shirt baju = new Shirt(warnabaju);
        Box kotak = new Box();
        System.out.println(baju.shirtColor);
        sc.close();
    }
}
