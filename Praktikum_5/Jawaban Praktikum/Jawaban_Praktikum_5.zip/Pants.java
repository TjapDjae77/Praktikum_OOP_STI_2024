public class Pants {
    public String pantsColor;

    public Pants(String color) {
        this.pantsColor = color;
    }
}