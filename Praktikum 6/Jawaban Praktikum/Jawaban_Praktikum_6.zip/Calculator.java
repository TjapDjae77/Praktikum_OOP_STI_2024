// NIM: 18222105
//NAMA: Rajendra Farras Rayhan

public class Calculator {
    // private double a;
    // private double b;
    // private char operation;

    public Calculator() {

    }

    public double calculate(double a, double b, char operation) throws InvalidOperationException, InvalidDivisionException {
        if(operation == '+'){
            return a+b;
        }
        else if(operation == '-'){
            return a-b;
        }
        else if(operation == '*'){
            return a*b;
        }
        else if(operation == '/'){
            if(b == 0){
                throw new InvalidDivisionException();
            }
            else{
                return a/b;
            }
        }
        else{
            throw new InvalidOperationException(operation);
        }
        /**
         * Implementasi
         * Apabila operasi yang dimasukkan pengguna bukan `+`, `-`, `*`, atau `/`, maka
         * kalkulator akan mengembalikan pesan error dari kelas
         * `InvalidOperationException` dengan pesan `Invalid Operation: <operasi yang dimasukan>`
         * 
         * Apabila kalkulator menerima masukan pembagian terhadap 0, maka kalkulator
         * akan mengembalikan pesan error dari kelas `InvalidDivisionException`
         * dengan pesan `Invalid Division: Tidak dapat melakukan pembagian terhadap 0!`
         */ 
    }
}

class CalculatorException extends Exception{
    public CalculatorException(){
        super();
    }
}

class InvalidOperationException extends CalculatorException {
    public InvalidOperationException(char operation){
        super();
        getMessage(operation);
    }
    public String getMessage(char operation){
        return ("Invalid Operation: " + operation);
    }
}

class InvalidDivisionException extends CalculatorException {
    public InvalidDivisionException(){
        super();
        getMessage();
    }
    public String getMessage(){
        return ("Invalid Division: Tidak dapat melakukan pembagian terhadap 0!");
    }
}
/**
 * Implementasikan:
 * 1. Calculator Exception
 * 2. InvalidOperationException
 * 3. InvalidDivisionException
 */