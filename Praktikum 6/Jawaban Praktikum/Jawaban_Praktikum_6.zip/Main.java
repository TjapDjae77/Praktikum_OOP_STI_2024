// NIM: 18222105
// NAMA: RAJENDRA FARRAS RAYHAN

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        try{
            String mail = sc.nextLine();
            Email email = new Email(mail);
            if(mail.equals("")){
                System.out.println("Email tidak boleh kosong");
                System.out.println("Email string error!");
            }
            else{
                System.out.println(email.validateEmail());
                System.out.println("Email validated.");
            }
        }
        catch(InvalidEmailException e){
            System.out.println(e.getClass().getName() + "! " + e.getMessage());
            System.out.println("Email string error!");
        }
        catch(InvalidDomainException e){
            System.out.println(e.getClass().getName() + "! " + e.getMessage());
            System.out.println("Email string error!");
        }
        finally {
            System.out.println("Operation finished.");
        }
        sc.close();
    }
}