import java.util.List;

/**
 * Jangan lupa tambahkan kata kunci yang dibutuhkan
 */ 



public class Cart extends Exception{
    /**
     * Tambahkan atribut kelas disini
     */ 
    private List<Item> items;
    private Account account;

    /**
     * Konstruktor
     * Inisialisasi atribut kelas
     */
    public Cart(Account account) {
        this.account = account;
    }
    
    /**
     * Implementasi
     * return account
     */
    public Account getAccount() {
        return account;
    }

    /**
     * Implementasi
     * return list item
     */
    public List<Item> getItems() {
        return items;
    }

    /**
     * Implementasi
     * menambahkan item ke dalam list item
     */
    public void addItem(Item item) {
        items.add(item);
    }

    /**
     * Implementasi
     * menghapus semua item yang memiliki nama sesuai dengan parameter name
     * 
     * Apabila keranjang kosong, lempar exception "Tidak ada barang di dalam keranjang"
     * Apabila barang tidak ditemukan, lempar exception "Barang tidak ditemukan di dalam keranjang"
     */
    public void removeItem(String name) throws Exception {
        if(items.isEmpty()){
            throw new Exception("Tidak ada barang di dalam keranjang");
        }
        else if(items.indexOf(name) == -1){
            throw new Exception("Barang tidak ditemukan di dalam keranjang");
        }
        else{
            for(Item listitem : items){
                if(listitem.getName().equals(name)){
                    items.remove(listitem);
                }
            }
        }
    }

    /**
     * Implementasi
     * mengembalikan total harga semua barang di dalam keranjang
     */
    public int getTotalPrice() {
        int totalPrice = 0;
        for(Item listitem : items){
            totalPrice += listitem.getTotalPrice();
        }
        return totalPrice;
    }

    /**
     * Implementasi
     * mengurangi saldo sejumlah total harga semua barang
     * mengosongkan keranjang
     * 
     * Apabila keranjang kosong, lempar exception "Keranjang kosong"
     * Apabila saldo tidak mencukupi, lempar exception "Saldo tidak mencukupi untuk melakukan pembayaran"
     */
    public void checkout() throws Exception {
        if(items.isEmpty()){
            throw new Exception("Keranjang kosong");
        }
        else if(account.getSaldo() < getTotalPrice()){
            throw new Exception("Saldo tidak mencukupi untuk melakukan pembayaran");
        }
        else{
            account.reduceSaldo(getTotalPrice());
            items.clear();
        }
    }
}