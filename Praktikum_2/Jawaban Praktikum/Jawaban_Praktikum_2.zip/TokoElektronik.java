import java.lang.System;
import java.util.Scanner;


public class TokoElektronik {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int totalHarga = 0;
        int quantity = Integer.parseInt(scanner.nextLine());
        
        
        while (quantity > 0){
            int choice = Integer.parseInt(scanner.nextLine());
            String merk = scanner.nextLine();
            String modelnya = scanner.nextLine();
            if(choice == 1){ // pilihan Smartphone
                int memori = Integer.parseInt(scanner.nextLine());
                int dayabaterai = Integer.parseInt(scanner.nextLine());

                Smartphone HP = new Smartphone(merk, modelnya, memori, dayabaterai);
                int harga = HP.calculatePrice();
                HP.displayDetails();
                System.out.println("Price: " + harga);
                totalHarga += harga;
            }
            else if(choice == 2){ // pilihan Laptop
                String prosesor = scanner.nextLine();
                int jumlahram = Integer.parseInt(scanner.nextLine());
                int masukaninput = Integer.parseInt(scanner.nextLine());
                String inputS;
                if(masukaninput == 1){
                    inputS = "True";
                }
                else{
                    inputS = "False";
                }
                boolean layarsentuh = Boolean.parseBoolean(inputS);

                Laptop laptop = new Laptop(merk, modelnya, prosesor, jumlahram, layarsentuh);
                int harga = laptop.calculatePrice();
                laptop.displayDetails();
                System.out.println("Price: " + harga);
                totalHarga += harga;
            }
            else{ // pilihan Tablet
                int ukuranlayar = Integer.parseInt(scanner.nextLine());
                int masukaninput = Integer.parseInt(scanner.nextLine());
                String inputS;
                if(masukaninput == 1){
                    inputS = "True";
                }
                else{
                    inputS = "False";
                }
                boolean selular = Boolean.parseBoolean(inputS);

                Tablet tab = new Tablet(merk, modelnya, ukuranlayar, selular);
                int harga = tab.calculatePrice();
                tab.displayDetails();
                System.out.println("Price: " + harga);
                totalHarga += harga;
            }
            quantity--;
        }
        System.out.println("Total price: " + totalHarga);
        scanner.close();
    }
}
