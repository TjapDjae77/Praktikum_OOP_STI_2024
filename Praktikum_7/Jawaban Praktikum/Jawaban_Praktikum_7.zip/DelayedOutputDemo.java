public class DelayedOutputDemo {
    public static void main(String[] args){
        DelayedOutput.printDelayed(200, "Halo 1");
        DelayedOutput.printDelayed(100, "Halo 2");
    }
}
