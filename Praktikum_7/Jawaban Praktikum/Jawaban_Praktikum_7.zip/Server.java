public class Server {
    // nWorkers menyatakan jumlah maximum threads yang tersedia pada server a.k.a thread pool
    private int workers;
    private int[] countWord;

    Server(int workers) {
        // Lengkapi kode berikut
        this.workers = workers;
    }

    public Integer[] process(String[] requests) throws InterruptedException {
        // process akan membuat threads dan memetakan elemen-elemen requests kepada threads tersebut
        // setiap thread kemudian memanggil method count
        // main thread (thread yang invoked method ini) akan menunggu semua thread selesai
        // terakhir main thread akan mengembalikan hasil penghitungan kata untuk setiap elemen requests
        // Lengkapi kode berikut
        try {
            
            for(int i = requests.length; i > 0; i -= workers){
                for(int j = 0; j < workers; j++){
                    
                }
            }
        } catch (Exception e) {
            // TODO: handle exception
        }
        
        return countWord;
    }

    protected int count(String request) {
        // Lengkapi kode berikut
        int countingwords = 0;
        int skipspace = 0;
        while (request.charAt(i) == ' '){
            skipspace++;
        }
        for(int i = skipspace; i < request.length(); i++){
            if(request.charAt(i) == ' '){
                countingwords++;
            }
        }
        return countingwords;
    }
}