/**
* ArraySum.java 
* @author 18222105 Rajendra Farras Rayhan
*/

/**
 * Jangan lupa tambahkan kata kunci yang dibutuhkan
 */ 

public class ArraySum extends Thread{
    // nWorkers menyatakan jumlah maksimum threads yang tersedia
    private int nWorkers;
    // array untuk menampung array masukan
    private Integer[] arr;
    /**
     * Tambahkan atribut kelas yang dibutuhkan
     */ 
    private Thread[] threads;
    static int[] sum = {0};
    int finalsum =0;

    /**
     * Konstruktor
     * Inisialisasi atribut kelas
     */
    ArraySum(int nWorkers, Integer[] arr) {
        threads = new Thread[nWorkers];
        this.nWorkers = nWorkers;
        this.arr = arr;
    }

    /**
     * Implementasi
     * method sum akan membuat sejumlah thread dan memetakan array masukan secara merata ke semua threads yang dapat dibuat
     */
    public int sum() throws InterruptedException {
        
        try {
            int load = arr.length;
            int starting = 0;
            int ending;
            for(int i = 0; i < arr.length; i++){
                ending = starting + (load/nWorkers);
                final int start = starting;
                final int end = ending;
                threads[i] = new Thread(new Runnable() {
                    public void run() {
                        sum[0] += partialSum(start, end);
                    }
                });
                finalsum += partialSum(start, end);
                nWorkers--;
                load -= ending - starting;
                starting = ending;
            }
            
        } catch (Exception e) {

        }

        return finalsum;
    }

    /**
     * Implementasi
     * method partialSum akan melakukan penjumlahan elemen-elemen array pada index `start` sampai `end-1`
     */
    protected int partialSum(int start, int end) {
        int sum = 0;

        for (int i = start; i < end; i++) {
            sum += arr[i];
        }

        return sum;
    }
}