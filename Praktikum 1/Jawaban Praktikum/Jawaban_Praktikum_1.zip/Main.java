public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int type = input.nextInt();
        double x = input.nextDouble();
        String s = input.next();
        System.out.println(x);
    }
}