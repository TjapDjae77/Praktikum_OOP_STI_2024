// NIM  : 18222105
// NAMA : Rajendra Farras Rayhan
import java.lang.System;
import java.util.Scanner;

public class GameSimulator {
    public static void main (String[] args){
        Scanner scanner = new Scanner(System.in);

        int pemain = Integer.parseInt(scanner.nextLine());
        String pencari = scanner.nextLine();

        HideNSeek game = new HideNSeek(pencari, pemain);
        System.out.printf("Game dimulai dengan %d pemain, seeker adalah %s\n", pemain, pencari);
        int x = game.getPlayerFound();
        int jumlah_pemain = game.getPlayer();
        while (x < jumlah_pemain-1){
            int ketemu_pemain = Integer.parseInt(scanner.nextLine());
            if(ketemu_pemain == (x+1)){
                game.foundPlayer();
                x = x+1;
                System.out.printf("%d Pemain ditemukan\n", x);
            }
        }
        System.out.println("Semua pemain telah ditemukan, permainan selesai.");
        scanner.close();
    }
}
