public class Bicycle implements Vehicle, Tyre {
    public void park() {
        System.out.println("Bicycle park");
    }

    public void changeTyre() {
        System.out.println("Bicycle changeTyre");
    }
}
