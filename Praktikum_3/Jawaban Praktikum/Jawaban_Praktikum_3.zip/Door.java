public interface Door {
    public void openDoor();
    public void closeDoor();
}
